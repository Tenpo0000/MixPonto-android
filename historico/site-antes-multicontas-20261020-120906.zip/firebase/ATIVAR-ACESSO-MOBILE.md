# Ativar o acesso móvel no Firebase publicado

O erro informado pelo site indica que a conta antiga ainda não tem `contas/UID/meta/ownerUid` correto. A inicialização agora completa esse campo quando ele está ausente, preservando funcionários, registros e demais metadados. Um titular divergente não é substituído.

As regras enviadas em 20/10/2026 permitem somente `contas/UID`. Elas bloqueiam `solicitacoesMobile` e `acessosMobile`, necessários para o acesso pelo Android. Modificar o site ou instalar o APK não publica regras no Firebase.

## Aplicar no Console

1. No projeto **mixponto-ffe50**, abra **Authentication → Users** e copie o UID da conta administradora que entra no site.
2. Em **Realtime Database → Dados**, adicione na raiz `titularesAutorizados`, com um filho cujo nome é esse UID e cujo valor é o booleano `true`. Não coloque o UID de funcionário nessa lista e não substitua a raiz do banco. Essa lista identifica os administradores existentes e impede a promoção de funcionários pelo próprio aplicativo.
3. Guarde uma cópia das regras atuais. Em **Realtime Database → Regras**, substitua o conteúdo pelo arquivo `database.rules.json` desta pasta e clique em **Publicar**. O arquivo foi combinado com as validações de UID, índice de cartão e `cartaoVersao` das regras enviadas. Repita o passo 2 para outros titulares legítimos antes de publicar.
4. Atualize o site com **Ctrl + F5**, entre como administrador e abra **Cadastro → Funcionário**. Use um e-mail individual diferente do administrador, preencha senha e confirmação e clique em **Salvar Funcionário**. Para um vínculo revogado, use **Salvar e liberar acesso novamente**.
5. Aguarde a confirmação de cadastro e acesso salvos. Reabra o funcionário e confira e-mail e senha. No Android, saia da conta atual e entre com o e-mail e a senha desse funcionário.

## Conferir a gravação

Depois da confirmação, devem existir:

- `contas/UID_TITULAR/meta/ownerUid`: UID do administrador.
- `contas/UID_TITULAR/funcionarios/ID/emailApp` e `appAuthUid`: e-mail e UID do login do funcionário.
- `contas/UID_TITULAR/credenciaisApp/ID`: cópia administrativa recuperável do e-mail e da senha. A senha não fica dentro do registro pessoal.
- `contas/UID_TITULAR/mobileConfig/ID`: configuração da admissão.
- `acessosMobile/UID_FUNCIONARIO`: vínculo ativo com empresa e funcionário.

O botão **Atualizar acesso** do Android só consulta esse vínculo. Ele não cria a autorização. Os testes locais usam emuladores; a publicação e o teste no celular precisam ser confirmados no ambiente real.
