const ZONE = 'America/Sao_Paulo';
const MIN_INTERVAL = 5 * 60 * 1000;

class DomainError extends Error {
    constructor(code, message) {
        super(message);
        this.code = code;
    }
}

function dayKey(time) {
    const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: ZONE,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
    }).formatToParts(new Date(time));
    const value = (type) => parts.find((p) => p.type === type).value;
    return `${value('year')}-${value('month')}-${value('day')}`;
}

function parseTimestamp(value) {
    if (typeof value !== 'string') return NaN;
    // O firmware antigo do ESP32 gravava horário de Brasília sem o sufixo UTC.
    const local = /T\d{2}:\d{2}:\d{2}(?:\.\d+)?$/.test(value);
    return Date.parse(local ? `${value}-03:00` : value);
}

function validDate(value) {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value))
        return false;
    const ms = Date.parse(`${value}T00:00:00Z`);
    return (
        Number.isFinite(ms) && new Date(ms).toISOString().slice(0, 10) === value
    );
}

function employee(account, employeeId, uid) {
    const f = account?.funcionarios?.[employeeId];
    if (!f || f.acessosMobile?.[uid] !== true) {
        throw new DomainError(
            'permission-denied',
            'Seu acesso não está vinculado a este funcionário.',
        );
    }
    if (f.status === 'desligado') {
        throw new DomainError(
            'failed-precondition',
            'Funcionário desligado. Procure o administrador.',
        );
    }
    return f;
}

function applyPunch(account, uid, employeeId, requestId, now) {
    if (
        typeof requestId !== 'string' ||
        !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
            requestId,
        )
    ) {
        throw new DomainError(
            'invalid-argument',
            'Identificador de envio inválido.',
        );
    }
    const f = employee(account, employeeId, uid);
    const previous = account.mobileSolicitacoes?.[uid]?.[requestId];
    if (previous) return previous;
    const day = dayKey(now);
    if (!validDate(f.admissao) || day < f.admissao) {
        throw new DomainError(
            'failed-precondition',
            'Confira a data de admissão no cadastro do funcionário.',
        );
    }
    for (const offset of [-86400000, 0, 86400000]) {
        const records =
            account.registros?.[dayKey(now + offset)]?.[employeeId] || {};
        if (
            Object.values(records).some(
                (r) =>
                    Math.abs(now - parseTimestamp(r.timestamp)) < MIN_INTERVAL,
            )
        ) {
            throw new DomainError(
                'failed-precondition',
                'Aguarde pelo menos 5 minutos entre as batidas.',
            );
        }
    }
    const receipt = {
        id: `app_${requestId}`,
        dia: day,
        timestamp: new Date(now).toISOString(),
        nome: f.nome || 'Funcionário',
    };
    (((account.registros ||= {})[day] ||= {})[employeeId] ||= {})[receipt.id] =
        {
            nome: receipt.nome,
            timestamp: receipt.timestamp,
            origem: 'android',
            authUid: uid,
            requestId,
        };
    ((account.mobileSolicitacoes ||= {})[uid] ||= {})[requestId] = receipt;
    return receipt;
}

function records(account, employeeId, now) {
    const out = [];
    const labels = ['Entrada', 'Saída para intervalo', 'Retorno', 'Saída'];
    for (let i = 0; i < 7; i++) {
        const day = dayKey(now - i * 86400000);
        const values = Object.entries(
            account.registros?.[day]?.[employeeId] || {},
        )
            .filter(([, r]) => Number.isFinite(parseTimestamp(r.timestamp)))
            .sort(
                (a, b) =>
                    parseTimestamp(a[1].timestamp) -
                    parseTimestamp(b[1].timestamp),
            );
        values.forEach(([id, r], index) =>
            out.push({
                id,
                dia: day,
                timestamp: new Date(parseTimestamp(r.timestamp)).toISOString(),
                tipo: labels[index] || `Batida ${index + 1}`,
                origem: r.origem || (r.manual ? 'manual' : 'terminal'),
            }),
        );
    }
    return out;
}

module.exports = {
    DomainError,
    dayKey,
    parseTimestamp,
    validDate,
    employee,
    applyPunch,
    records,
};
