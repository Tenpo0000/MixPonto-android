const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');
const { getAuth } = require('firebase-admin/auth');
const {
    DomainError,
    dayKey,
    employee,
    applyPunch,
    records,
} = require('./domain');

initializeApp({
    databaseURL: 'https://mixponto-ffe50-default-rtdb.firebaseio.com',
});
const db = getDatabase();
const options = {
    region: 'southamerica-east1',
    maxInstances: 5,
    timeoutSeconds: 60,
};

function callable(handler) {
    return onCall(options, async (request) => {
        if (!request.auth)
            throw new HttpsError('unauthenticated', 'Entre na sua conta.');
        try {
            return await handler(request.auth.uid, request.data || {});
        } catch (error) {
            if (error instanceof HttpsError) throw error;
            if (error instanceof DomainError)
                throw new HttpsError(error.code, error.message);
            console.error('Falha mobile:', error.code || error.name);
            throw new HttpsError(
                'internal',
                'Não foi possível concluir. Tente novamente.',
            );
        }
    });
}

function identifier(value) {
    if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(value)) {
        throw new HttpsError('invalid-argument', 'Identificador inválido.');
    }
    return value;
}

async function owner(uid) {
    if ((await db.ref(`contas/${uid}/meta/ownerUid`).get()).val() !== uid) {
        throw new HttpsError(
            'permission-denied',
            'Apenas o titular da empresa pode gerenciar acessos.',
        );
    }
}

async function verified(uid) {
    const user = await getAuth().getUser(uid);
    if (user.disabled || !user.emailVerified) {
        throw new HttpsError(
            'failed-precondition',
            'Confirme seu e-mail e mantenha a conta ativa para continuar.',
        );
    }
}

async function access(uid) {
    await verified(uid);
    const link = (await db.ref(`acessosMobile/${uid}`).get()).val();
    if (!link?.empresaUid || !link?.funcionarioId) {
        throw new HttpsError(
            'permission-denied',
            'Peça ao administrador para vincular seu e-mail ao funcionário.',
        );
    }
    identifier(link.empresaUid);
    identifier(link.funcionarioId);
    return link;
}

exports.mobilePerfil = callable(async (uid) => {
    if ((await db.ref(`contas/${uid}/meta/ownerUid`).get()).val() === uid) {
        const account = (await db.ref(`contas/${uid}`).get()).val();
        const funcionarios = await Promise.all(
            Object.entries(account.funcionarios || {}).map(async ([id, f]) => {
                const acessos = await Promise.all(
                    Object.keys(f.acessosMobile || {})
                        .filter((k) => f.acessosMobile[k] === true)
                        .map(async (loginUid) => {
                            const link = (
                                await db.ref(`acessosMobile/${loginUid}`).get()
                            ).val();
                            return {
                                uid: loginUid,
                                email:
                                    link?.empresaUid === uid &&
                                    link?.funcionarioId === id
                                        ? link.email
                                        : 'Vínculo desatualizado',
                            };
                        }),
                );
                return {
                    id,
                    nome: f.nome || 'Funcionário',
                    status: f.status || 'ativo',
                    acessos,
                };
            }),
        );
        funcionarios.sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
        return {
            modo: 'administrador',
            empresa: account.empresa?.nome || 'Sua empresa',
            funcionarios,
        };
    }
    const link = await access(uid);
    const account = (await db.ref(`contas/${link.empresaUid}`).get()).val();
    const f = employee(account, link.funcionarioId, uid);
    const now = Date.now();
    return {
        modo: 'funcionario',
        nome: f.nome,
        matricula: f.matricula || '',
        empresa:
            account.empresas?.[f.empresaId]?.nome ||
            account.empresa?.nome ||
            'Sua empresa',
        hoje: dayKey(now),
        registros: records(account, link.funcionarioId, now),
    };
});

exports.mobileBaterPonto = callable(async (uid, data) => {
    const link = await access(uid);
    const now = Date.now();
    let failure;
    // A transação mantém autorização, batida e comprovante na mesma alteração.
    const result = await db
        .ref(`contas/${link.empresaUid}`)
        .transaction((account) => {
            failure = null;
            if (account === null) return null;
            try {
                applyPunch(
                    account,
                    uid,
                    link.funcionarioId,
                    data.requestId,
                    now,
                );
                return account;
            } catch (error) {
                failure = error;
                return undefined;
            }
        });
    if (failure) throw failure;
    const receipt =
        typeof data.requestId === 'string' &&
        /^[a-f0-9-]{36}$/i.test(data.requestId)
            ? result.snapshot
                  .child(`mobileSolicitacoes/${uid}/${data.requestId}`)
                  .val()
            : null;
    if (!result.committed || !receipt)
        throw new HttpsError(
            'unavailable',
            'Envio não confirmado. Tente novamente.',
        );
    return receipt;
});

exports.mobileVincular = callable(async (uid, data) => {
    await owner(uid);
    const fid = identifier(data.funcionarioId);
    const email = String(data.email || '')
        .trim()
        .toLowerCase();
    if (!email || email.length > 254)
        throw new HttpsError('invalid-argument', 'Informe o e-mail.');
    let target;
    try {
        target = await getAuth().getUserByEmail(email);
    } catch (error) {
        if (error.code === 'auth/user-not-found')
            throw new HttpsError(
                'not-found',
                'O funcionário precisa criar a conta pelo aplicativo primeiro.',
            );
        throw error;
    }
    await verified(target.uid);
    if (
        (await db.ref(`contas/${target.uid}/meta/ownerUid`).get()).val() ===
        target.uid
    ) {
        throw new HttpsError(
            'failed-precondition',
            'Use uma conta individual de funcionário, diferente da conta titular.',
        );
    }
    const fRef = db.ref(`contas/${uid}/funcionarios/${fid}`);
    const f = (await fRef.get()).val();
    if (!f || f.status === 'desligado')
        throw new HttpsError(
            'failed-precondition',
            'Funcionário inexistente ou desligado.',
        );
    const linkRef = db.ref(`acessosMobile/${target.uid}`);
    const link = await linkRef.transaction((current) => {
        if (
            current &&
            (current.empresaUid !== uid || current.funcionarioId !== fid)
        )
            return undefined;
        return {
            empresaUid: uid,
            funcionarioId: fid,
            email,
            vinculadoEm: Date.now(),
        };
    });
    if (!link.committed)
        throw new HttpsError(
            'already-exists',
            'Este login já está vinculado. Revogue o acesso anterior antes de transferir.',
        );
    const granted = await fRef.transaction((current) => {
        if (current === null) return null;
        if (current.status === 'desligado') return undefined;
        (current.acessosMobile ||= {})[target.uid] = true;
        return current;
    });
    if (!granted.committed || !granted.snapshot.exists()) {
        await linkRef.transaction((current) =>
            current?.empresaUid === uid && current?.funcionarioId === fid
                ? null
                : undefined,
        );
        throw new HttpsError(
            'failed-precondition',
            'Funcionário alterado. Atualize a lista.',
        );
    }
    return { email, nome: f.nome };
});

exports.mobileRevogar = callable(async (uid, data) => {
    await owner(uid);
    const fid = identifier(data.funcionarioId);
    const loginUid = identifier(data.loginUid);
    const ref = db.ref(`acessosMobile/${loginUid}`);
    const link = (await ref.get()).val();
    if (link?.empresaUid !== uid || link?.funcionarioId !== fid) {
        throw new HttpsError(
            'permission-denied',
            'Vínculo não pertence a este funcionário.',
        );
    }
    await db
        .ref(`contas/${uid}/funcionarios/${fid}/acessosMobile/${loginUid}`)
        .remove();
    await ref.transaction((current) =>
        current?.empresaUid === uid && current?.funcionarioId === fid
            ? null
            : undefined,
    );
    return { removido: true };
});
