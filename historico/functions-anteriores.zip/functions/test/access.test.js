const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

function fixture() {
    const data = {
        contas: {
            company: {
                meta: { ownerUid: 'company' },
                funcionarios: {
                    f1: {
                        nome: 'Ana',
                        admissao: '2001-01-20',
                        acessosMobile: { worker: true },
                    },
                    f2: { nome: 'Bia', admissao: '2001-01-20' },
                },
            },
        },
        acessosMobile: {
            worker: {
                empresaUid: 'company',
                funcionarioId: 'f1',
                email: 'ana@example.com',
            },
        },
    };
    const users = {
        worker: {
            uid: 'worker',
            email: 'ana@example.com',
            emailVerified: true,
        },
        newcomer: {
            uid: 'newcomer',
            email: 'bia@example.com',
            emailVerified: true,
        },
    };
    const get = (p) =>
        p
            .split('/')
            .filter(Boolean)
            .reduce((o, k) => o?.[k], data) ?? null;
    function set(p, value) {
        const keys = p.split('/').filter(Boolean);
        let obj = data;
        for (const k of keys.slice(0, -1)) obj = obj[k] ||= {};
        if (value === null) delete obj[keys.at(-1)];
        else obj[keys.at(-1)] = value;
    }
    const snapshot = (p) => ({
        val: () => structuredClone(get(p)),
        exists: () => get(p) !== null,
        child: (s) => snapshot(`${p}/${s}`),
    });
    const db = {
        ref: (p) => ({
            get: async () => snapshot(p),
            remove: async () => set(p, null),
            transaction: async (fn) => {
                const value = fn(structuredClone(get(p)));
                if (value !== undefined) set(p, value);
                return {
                    committed: value !== undefined,
                    snapshot: snapshot(p),
                };
            },
        }),
    };
    class HttpsError extends Error {
        constructor(code, message) {
            super(message);
            this.code = code;
        }
    }
    const auth = {
        getUser: async (uid) => users[uid] || { uid, emailVerified: true },
        getUserByEmail: async (email) => {
            const user = Object.values(users).find((u) => u.email === email);
            if (!user)
                throw Object.assign(new Error(), {
                    code: 'auth/user-not-found',
                });
            return user;
        },
    };
    const exports = {};
    const modules = {
        'firebase-functions/v2/https': {
            onCall: (_, handler) => handler,
            HttpsError,
        },
        'firebase-admin/app': { initializeApp() {} },
        'firebase-admin/database': { getDatabase: () => db },
        'firebase-admin/auth': { getAuth: () => auth },
        './domain': require('../domain'),
    };
    vm.runInNewContext(
        fs.readFileSync(path.join(__dirname, '../index.js'), 'utf8'),
        { require: (name) => modules[name], exports, console, Date },
    );
    const call = (name, uid, payload = {}) =>
        exports[name]({ auth: uid ? { uid } : null, data: payload });
    return { data, users, call };
}

test('todos os endpoints exigem autenticação', async () => {
    const f = fixture();
    for (const endpoint of [
        'mobilePerfil',
        'mobileBaterPonto',
        'mobileVincular',
        'mobileRevogar',
    ]) {
        await assert.rejects(f.call(endpoint, null), {
            code: 'unauthenticated',
        });
    }
});
test('funcionário não pode administrar vínculos', async () => {
    const f = fixture();
    for (const endpoint of ['mobileVincular', 'mobileRevogar']) {
        await assert.rejects(f.call(endpoint, 'worker'), {
            code: 'permission-denied',
        });
    }
});
test('ignora identidade e horário forjados pelo cliente', async () => {
    const f = fixture();
    const r = await f.call('mobileBaterPonto', 'worker', {
        requestId: '12345678-1234-4123-8123-123456789abc',
        empresaUid: 'other',
        funcionarioId: 'f2',
        nome: 'Forjado',
        timestamp: '2001-01-20T10:00:00Z',
    });
    assert.equal(r.nome, 'Ana');
    assert.ok(Math.abs(Date.parse(r.timestamp) - Date.now()) < 5000);
    assert.equal(f.data.contas.company.registros[r.dia].f2, undefined);
});
test('perfil do funcionário não revela equipe', async () => {
    const f = fixture();
    const r = await f.call('mobilePerfil', 'worker');
    assert.equal(r.nome, 'Ana');
    assert.equal(r.funcionarios, undefined);
});
test('titular vincula e revoga sem apagar registros', async () => {
    const f = fixture();
    await f.call('mobileVincular', 'company', {
        funcionarioId: 'f2',
        email: 'bia@example.com',
    });
    const r = await f.call('mobileBaterPonto', 'newcomer', {
        requestId: '12345678-1234-4123-8123-123456789abc',
    });
    await f.call('mobileRevogar', 'company', {
        funcionarioId: 'f2',
        loginUid: 'newcomer',
    });
    assert.ok(f.data.contas.company.registros[r.dia].f2[r.id]);
    await assert.rejects(f.call('mobilePerfil', 'newcomer'), {
        code: 'permission-denied',
    });
});
test('não permite tomar vínculo de outra empresa', async () => {
    const f = fixture();
    f.data.acessosMobile.newcomer = {
        empresaUid: 'other',
        funcionarioId: 'f9',
    };
    await assert.rejects(
        f.call('mobileVincular', 'company', {
            funcionarioId: 'f2',
            email: 'bia@example.com',
        }),
        { code: 'already-exists' },
    );
});
test('bloqueia e-mail não confirmado e usuário desativado', async () => {
    const f = fixture();
    f.users.newcomer.emailVerified = false;
    await assert.rejects(
        f.call('mobileVincular', 'company', {
            funcionarioId: 'f2',
            email: 'bia@example.com',
        }),
        { code: 'failed-precondition' },
    );
    f.users.worker.disabled = true;
    await assert.rejects(f.call('mobileBaterPonto', 'worker'), {
        code: 'failed-precondition',
    });
});
