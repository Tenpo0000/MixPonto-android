const { test } = require('node:test');
const assert = require('node:assert/strict');
const {
    dayKey,
    validDate,
    parseTimestamp,
    applyPunch,
    records,
} = require('../domain');
const now = Date.parse('2026-10-17T15:00:00Z');
const id = '12345678-1234-4123-8123-123456789abc';
const second = '22345678-1234-4123-8123-123456789abc';
const account = () => ({
    funcionarios: {
        f1: {
            nome: 'Ana',
            admissao: '2026-10-17',
            status: 'ativo',
            acessosMobile: { user: true },
        },
    },
});
const punch = (a, request = id, time = now, uid = 'user') =>
    applyPunch(a, uid, 'f1', request, time);

test('dia segue Brasília na virada UTC', () =>
    assert.equal(dayKey(Date.parse('2026-10-17T01:00:00Z')), '2026-10-16'));
test('valida calendário real', () => {
    assert.equal(validDate('2024-02-29'), true);
    assert.equal(validDate('2026-02-29'), false);
    assert.equal(validDate('20/01/2001'), false);
});
test('grava no formato do site sem marcar como manual', () => {
    const a = account(),
        r = punch(a);
    const saved = a.registros['2026-10-17'].f1[r.id];
    assert.equal(saved.timestamp, '2026-10-17T15:00:00.000Z');
    assert.equal(saved.nome, 'Ana');
    assert.equal(saved.origem, 'android');
    assert.equal(saved.manual, undefined);
});
test('reenvio no dia seguinte devolve comprovante original', () => {
    const a = account(),
        original = punch(a);
    assert.deepEqual(punch(a, id, now + 86400000), original);
    assert.equal(Object.keys(a.registros).length, 1);
});
test('impede duas solicitações com menos de cinco minutos', () => {
    const a = account();
    punch(a);
    assert.throws(() => punch(a, second, now + 299999), {
        code: 'failed-precondition',
    });
});
test('permite outra batida após cinco minutos', () => {
    const a = account();
    punch(a);
    punch(a, second, now + 300000);
    assert.equal(Object.keys(a.registros['2026-10-17'].f1).length, 2);
});
test('compara registros do ESP32 na virada do dia', () => {
    const a = account();
    a.funcionarios.f1.admissao = '2026-10-16';
    a.registros = {
        '2026-10-16': { f1: { old: { timestamp: '2026-10-16T23:59:00' } } },
    };
    assert.throws(() => punch(a, id, Date.parse('2026-10-17T03:01:00Z')), {
        code: 'failed-precondition',
    });
});
test('bloqueia demitido', () => {
    const a = account();
    a.funcionarios.f1.status = 'desligado';
    assert.throws(() => punch(a), { code: 'failed-precondition' });
});
test('bloqueia funcionário inexistente e login sem vínculo', () => {
    assert.throws(() => punch({}), { code: 'permission-denied' });
    assert.throws(() => punch(account(), id, now, 'outsider'), {
        code: 'permission-denied',
    });
});
test('revogação bloqueia inclusive recuperação de comprovante', () => {
    const a = account();
    punch(a);
    delete a.funcionarios.f1.acessosMobile.user;
    assert.throws(() => punch(a), { code: 'permission-denied' });
});
test('bloqueia admissão futura ou inválida', () => {
    for (const admission of ['2026-10-18', '', '2026-02-30']) {
        const a = account();
        a.funcionarios.f1.admissao = admission;
        assert.throws(() => punch(a), { code: 'failed-precondition' });
    }
});
test('rejeita identificadores de envio que contenham caminhos', () => {
    for (const value of ['../other', null, '', id + '/x']) {
        assert.throws(() => punch(account(), value), {
            code: 'invalid-argument',
        });
    }
});
test('histórico limitado a sete dias e ao funcionário', () => {
    const a = account();
    punch(a);
    a.registros['2026-10-17'].other = {
        x: { timestamp: new Date(now).toISOString() },
    };
    a.registros['2026-10-09'] = {
        f1: { old: { timestamp: '2026-10-09T12:00:00Z' } },
    };
    assert.equal(records(a, 'f1', now).length, 1);
});
test('normaliza timestamps antigos sem fuso', () => {
    assert.equal(parseTimestamp('2026-10-17T12:00:00'), now);
    const a = account();
    a.registros = {
        '2026-10-17': { f1: { x: { timestamp: '2026-10-17T12:00:00' } } },
    };
    assert.equal(
        records(a, 'f1', now)[0].timestamp,
        '2026-10-17T15:00:00.000Z',
    );
});
